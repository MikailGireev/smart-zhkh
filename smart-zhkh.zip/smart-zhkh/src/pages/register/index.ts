export { default as Register } from './ui/RegisterPage.vue';
