<script setup lang="ts"></script>

<template>
  <main>
    <h1>Hello world</h1>
  </main>
</template>
