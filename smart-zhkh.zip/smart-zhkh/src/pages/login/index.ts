export { default as Login } from './ui/LoginPage.vue';
