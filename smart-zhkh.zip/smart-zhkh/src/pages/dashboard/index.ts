export { default as Dashboard } from './ui/DashboardPage.vue';
