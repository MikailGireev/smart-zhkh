CREATE DATABASE "personal-account-db";
CREATE DATABASE "billing-db";
CREATE DATABASE "payment-db";